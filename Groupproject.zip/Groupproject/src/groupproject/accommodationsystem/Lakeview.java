package groupproject.accommodationsystem;
public class Lakeview extends Area {
    public Lakeview(String areaName,String areaDescription){
            super(areaName, areaDescription);
            }
    public String getareaName(){
       return "Lakeview"; 
    }
    public String getareaDescription(){
        return areaDescription;
    }
}
