
public class AccommodationSystemException extends Exception
{
    public AccommodationSystemException(String message)
    {
        super(message);
    }
}
