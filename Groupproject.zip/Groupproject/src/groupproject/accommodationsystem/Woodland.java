package groupproject.accommodationsystem;
public class Woodland extends Area {
    public Woodland(String areaName,String areaDescription){
            super(areaName, areaDescription);
            }
    public String getareaName(){
       return "Woodland"; 
    }
    public String getareaDescription(){
        return areaDescription;
    }
}
