package groupproject.accommodationsystem;

public class Customer {
    private String firstName;
    private String lastName;
    private String mobileNo;

    public Customer(String firstName, String lastName, String mobileNo) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.mobileNo = mobileNo;
    }

    public String getFirstName() {
        return firstName; // Return actual instance variable
    }

    public String getLastName() {
        return lastName; // Return actual instance variable
    }

    public String getMobileNo() {
        return mobileNo; // Return actual instance variable
    }
}
