package groupproject.accommodationsystem;
public class Hilltop extends Area {
    public Hilltop(String areaName,String areaDescription){
            super(areaName, areaDescription);
            }
    
    
    public String getareaName(){
       return "Hilltop"; 
    }
    public String getareaDescription(){
        return areaDescription;
    }
}
